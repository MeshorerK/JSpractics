const giftArr = [
    {
        title: "Скидка 20% на первую покупку в нашем магазине!",
        icon: "/img/discount.svg"
    },
    {
        title: "Скидка 10% на всё!",
        icon: "/img/discount_2.svg"
    },
    {
        title: "Подарок при первой покупке в нашем магазине!",
        icon: "/img/gift.svg"
    },
    {
        title: "Бесплатная доставка для вас!",
        icon: "/img/delivery.svg"
    },
    {
        title: "Сегодня день больших скидок!",
        icon: "/img/discount_3.svg"
    }
];

function showRandomGift() {
    const randomIndex = Math.floor(Math.random() * giftArr.length);
    const selectedGift = giftArr[randomIndex];

    document.getElementById('gift-icon').src = selectedGift.icon;
    document.getElementById('gift-title').innerText = selectedGift.title;

    const popup = document.getElementById('popup');
    popup.classList.remove('hidden');
}

document.getElementById('close-button').addEventListener('click', function () {
    const popup = document.getElementById('popup');
    popup.classList.add('hidden');
});

setTimeout(showRandomGift, 3000);