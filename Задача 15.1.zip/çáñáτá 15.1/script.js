document.addEventListener('DOMContentLoaded', () => {
    const filmForm = document.getElementById('film-form');
    const filmList = document.getElementById('film-list');
    const errorMessage = document.getElementById('error-message');
    const sortSelect = document.getElementById('sort');

    let films = JSON.parse(localStorage.getItem('films')) || [];

    function renderFilms() {
        filmList.innerHTML = ''; 
        films.forEach((film, index) => {
            const row = document.createElement('tr');
    
            const titleCell = document.createElement('td');
            titleCell.textContent = film.title;
    
            const genreCell = document.createElement('td');
            genreCell.textContent = film.genre;
    
            const yearCell = document.createElement('td');
            yearCell.textContent = film.year;
    
            const actionCell = document.createElement('td');
    
            const editButton = document.createElement('button');
            editButton.textContent = 'Редактировать';
            editButton.onclick = () => editFilm(index);
    
            const deleteButton = document.createElement('button');
            deleteButton.textContent = 'Удалить';
            deleteButton.onclick = () => deleteFilm(index);
    
            actionCell.appendChild(editButton);
            actionCell.appendChild(deleteButton);
    
            row.appendChild(titleCell);
            row.appendChild(genreCell);
            row.appendChild(yearCell);
            row.appendChild(actionCell);
    
            filmList.appendChild(row);
        });
    }

    function saveFilms() {
        localStorage.setItem('films', JSON.stringify(films));
        renderFilms();
    }

    filmForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const title = document.getElementById('title').value;
        const genre = document.getElementById('genre').value;
        const year = document.getElementById('year').value;

        if (!title || !genre || !year) {
            errorMessage.textContent = 'Пожалуйста, заполните все поля!';
            return;
        }

        errorMessage.textContent = '';
        
        films.push({ title, genre, year });
        saveFilms();

        filmForm.reset();
    });

    window.deleteFilm = (index) => {
        films.splice(index, 1);
        saveFilms();
    };

    window.editFilm = (index) => {
        const film = films[index];
        document.getElementById('title').value = film.title;
        document.getElementById('genre').value = film.genre;
        document.getElementById('year').value = film.year;

        deleteFilm(index);
    };

    sortSelect.addEventListener('change', () => {
        const sortKey = sortSelect.value;
        films.sort((a, b) => a[sortKey].localeCompare(b[sortKey]));
        saveFilms();
    });

    renderFilms();
});

document.getElementById('applyFilter').addEventListener('click', applyFilter);

function applyFilter() {
    const title = document.getElementById('filterTitle').value;
    const genre = document.getElementById('filterGenre').value;
    const year = document.getElementById('filterYear').value;

    fetch(`/films?title=${title}&genre=${genre}&releaseYear=${year}`)
        .then(response => response.json())
        .then(data => {
            films = data; 
            renderFilms(); 
        });
}
function deleteFilm(index) {
    const filmId = films[index].id;
    fetch(`/films/${filmId}`, {
        method: 'DELETE'
    })
    .then(response => {
        if (response.ok) {
            films.splice(index, 1); 
            renderFilms(); 
        } else {
            console.error('Ошибка при удалении фильма');
        }
    });
}

document.getElementById('deleteAll').addEventListener('click', deleteAllFilms);

function deleteAllFilms() {
    fetch('/films', {
        method: 'DELETE'
    })
    .then(response => {
        if (response.ok) {
            films = []; 
            renderFilms(); 
        } else {
            console.error('Ошибка при удалении всех фильмов');
        }
    });
}

function validateFilm(title, genre, year) {
    if (!title || !genre || !year) {
        alert('Пожалуйста, заполните все поля!');
        return false;
    }
    return true;
}

function addFilm() {
    const title = document.getElementById('filmTitle').value;
    const genre = document.getElementById('filmGenre').value;
    const year = document.getElementById('filmYear').value;

    if (!validateFilm(title, genre, year)) return;

}

