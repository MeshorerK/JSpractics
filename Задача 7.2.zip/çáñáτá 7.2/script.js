let heights = [];

function renderHeights() {
    const heightList = document.getElementById('height-list');
    heightList.innerHTML = ''; 

    heights.forEach(height => {
        const li = document.createElement('li');
        li.textContent = `${height} см`;
        heightList.appendChild(li);
    });
}

document.getElementById('add-height').addEventListener('click', () => {
    const input = prompt("Введите рост ученика (в см):");
    
    if (input === null || input.trim() === '') {
        alert("Рост не введён!");
        return;
    }

    const height = parseInt(input);
    
    if (!isNaN(height) && height > 0) {
        heights.push(height);
        renderHeights();
    } else {
        alert("Пожалуйста, введите корректное значение роста!");
    }
});

document.getElementById('filter-height').addEventListener('click', () => {
    const filterValue = prompt("Введите минимальный рост для фильтрации:");

    if (filterValue === null || filterValue.trim() === '') {
        renderHeights();
        return;
    }

    const minHeight = parseInt(filterValue);
    
    if (!isNaN(minHeight) && minHeight >= 0) {
        const filteredHeights = heights.filter(height => height >= minHeight);
        heights = filteredHeights; 
        renderHeights();
    } else {
        alert("Пожалуйста, введите корректное значение!");
        renderHeights(); 
    }
});

renderHeights();
