document.querySelectorAll('.thumbnail').forEach(thumbnail => {
    thumbnail.addEventListener('click', function() {
        const imageUrl = this.src; 
        const fullImage = document.getElementById('fullImage');
        
        fullImage.src = imageUrl; 
        fullImage.style.display = 'block'; // Показываем изображение
    });
});
