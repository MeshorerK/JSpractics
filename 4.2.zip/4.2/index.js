const power = Number(prompt("Введите мощность двигателя"))

if (power <=100) {
    console.log("Сумма налога:", power*12);
} else if (power >=100 && power<=125) {
    console.log("Сумма налога:", power*25);
} else if (power >=125 && power<=150) {
    console.log("Сумма налога:", power*35);
} else if (power >=150 && power<=175) {
    console.log("Сумма налога:", power*45);
} else if (power >=175 && power<=200) {
    console.log("Сумма налога:", power*50);
} else if (power >=200 && power<=225) {
    console.log("Сумма налога:", power*65);
} else if (power >=225 && power<=250) {
    console.log("Сумма налога:", power*75);
} else {
    console.log("Сумма налога:", power*150);
}