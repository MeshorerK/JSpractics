let number = 0
const Year = 2024

let Name1 = prompt("Введите имя")
number++
let Birthday1 = prompt("Введите ваш год рождения")
let Age1 = Year - Birthday1
console.log(number, Name1, Age1);

let Name2 = prompt("Введите имя")
number++
let Birthday2 = prompt("Введите ваш год рождения")
let Age2 = Year - Birthday2
console.log(number, Name2, Age2);

let Name3 = prompt("Введите имя")
number++
let Birthday3 = prompt("Введите ваш год рождения")
let Age3 = Year - Birthday3
console.log(number, Name3, Age3);

let Midage = (Age1 + Age2 + Age3)/3

console.log("Средний возраст участников:", Midage);