const balance = 500
const trans = Number(prompt("Введите сумму"))
const card = 1

if (card ==1) {
    if (trans <= balance) {
        console.log("Операция выполняется")
    } 
    else {
        console.log("Операция отклонена")
    }
} 
else {
    console.log("Операция отклонена")
 }