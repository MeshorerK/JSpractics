let products = [];


function renderProducts() {
    const productList = document.getElementById('product-list');
    productList.innerHTML = ''; 

    products.sort();

    products.forEach(product => {
        const li = document.createElement('li');
        li.textContent = product;
        productList.appendChild(li);
    });
}

document.getElementById('add-product').addEventListener('click', () => {
    const input = prompt("Введите название товара:");

    if (input === null || input.trim() === '') {
        alert("Название товара не введено!");
        return;
    }

    products.push(input.trim());
    
    renderProducts();
});

renderProducts();

