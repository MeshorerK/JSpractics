document.getElementById('surveyForm').addEventListener('submit', function(event) {
    event.preventDefault(); 

    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const gender = document.querySelector('input[name="gender"]:checked') ? document.querySelector('input[name="gender"]:checked').value : '';
    const rating = document.getElementById('rating').value;
    const interests = Array.from(document.querySelectorAll('input[name="interests"]:checked')).map(el => el.value);
    const comments = document.getElementById('comments').value.trim();

    if (!name || !email) {
        alert('Имя и Email обязательны для заполнения!');
        return;
    }

    const emailPattern = /^[^s@]+@[^s@]+.[^s@]+$/; 
    if (!emailPattern.test(email)) {
        alert('Введите корректный email!');
        return;
    }

    let resultHTML = <h2>Результаты опроса:</h2>;
    resultHTML += <p><strong>Имя:</strong> ${name}</p>;
    resultHTML += <p><strong>Email:</strong> ${email}</p>;
    resultHTML += <p><strong>Пол:</strong> ${gender}</p>;
    resultHTML += <p><strong>Оценка сервиса:</strong> ${rating}</p>;
    resultHTML += <p><strong>Интересы:</strong> ${interests.length > 0 ? interests.join(', ') : 'Нет'}</p>;
    resultHTML += <p><strong>Комментарии:</strong> ${comments || 'Нет'}</p>;

    document.getElementById('result').innerHTML = resultHTML;

    document.getElementById('surveyForm').reset();
});
