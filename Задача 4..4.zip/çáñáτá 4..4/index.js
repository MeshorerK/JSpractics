 let count = 3

function summ() {
    if (typeof count == "number") {
        return count++;
    }
}

console.log(summ());
console.log(summ());
console.log(summ());
console.log(summ());
