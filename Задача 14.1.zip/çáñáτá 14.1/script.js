document.addEventListener('DOMContentLoaded', () => {
    const filmForm = document.getElementById('film-form');
    const filmList = document.getElementById('film-list');
    const errorMessage = document.getElementById('error-message');
    const sortSelect = document.getElementById('sort');

    let films = JSON.parse(localStorage.getItem('films')) || [];

    function renderFilms() {
        filmList.innerHTML = ''; 
        films.forEach((film, index) => {
            const row = document.createElement('tr');
    
            const titleCell = document.createElement('td');
            titleCell.textContent = film.title;
    
            const genreCell = document.createElement('td');
            genreCell.textContent = film.genre;
    
            const yearCell = document.createElement('td');
            yearCell.textContent = film.year;
    
            const actionCell = document.createElement('td');
    
            const editButton = document.createElement('button');
            editButton.textContent = 'Редактировать';
            editButton.onclick = () => editFilm(index);
    
            const deleteButton = document.createElement('button');
            deleteButton.textContent = 'Удалить';
            deleteButton.onclick = () => deleteFilm(index);
    
            actionCell.appendChild(editButton);
            actionCell.appendChild(deleteButton);
    
            row.appendChild(titleCell);
            row.appendChild(genreCell);
            row.appendChild(yearCell);
            row.appendChild(actionCell);
    
            filmList.appendChild(row);
        });
    }

    function saveFilms() {
        localStorage.setItem('films', JSON.stringify(films));
        renderFilms();
    }

    filmForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const title = document.getElementById('title').value;
        const genre = document.getElementById('genre').value;
        const year = document.getElementById('year').value;

        if (!title || !genre || !year) {
            errorMessage.textContent = 'Пожалуйста, заполните все поля!';
            return;
        }

        errorMessage.textContent = '';
        
        films.push({ title, genre, year });
        saveFilms();

        filmForm.reset();
    });

    window.deleteFilm = (index) => {
        films.splice(index, 1);
        saveFilms();
    };

    window.editFilm = (index) => {
        const film = films[index];
        document.getElementById('title').value = film.title;
        document.getElementById('genre').value = film.genre;
        document.getElementById('year').value = film.year;

        deleteFilm(index);
    };

    sortSelect.addEventListener('change', () => {
        const sortKey = sortSelect.value;
        films.sort((a, b) => a[sortKey].localeCompare(b[sortKey]));
        saveFilms();
    });

    renderFilms();
});
