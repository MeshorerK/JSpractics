const promocodeObj = {
    promocode: "PROM50",
    gift: "Скидка 50%"
};

function getCookie() {
    return document.cookie.split('; ').reduce((acc, item) => {
        const [name, value] = item.split('=');
        acc[name] = value;
        return acc;
    }, {});
}

function setCookie(name, value, days) {
    const expires = new Date(Date.now() + days * 864e5).toUTCString();
    document.cookie = name + '=' + encodeURIComponent(value) + '; expires=' + expires + '; path=/';
}

const cookie = getCookie();
if (cookie.promocode === promocodeObj.promocode) {
    showMessage(promocodeObj.gift);
}

document.getElementById('promocodeForm').addEventListener('submit', function(event) {
    event.preventDefault(); 
    const promocodeInput = document.getElementById('promocodeInput').value.trim();

    if (promocodeInput === promocodeObj.promocode) {
        setCookie('promocode', promocodeObj.promocode, 7);
        showMessage(promocodeObj.gift);
    } else {
        alert('Неверный промокод. Попробуйте еще раз.');
        resetForm();
    }
});

function showMessage(gift) {
    const messageDiv = document.getElementById('message');
    messageDiv.textContent = `Промокод активирован! ${gift}`;
    messageDiv.classList.remove('hidden');
}

function resetForm() {
    document.getElementById('promocodeInput').value = '';
}
