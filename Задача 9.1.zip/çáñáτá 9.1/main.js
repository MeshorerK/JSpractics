const cars = {
    dodge: {
        name: "Dodge RAM",
        wheels: 4,
        doors: 4,
        isStarted: false,
        hp: 500
    },
    bmw: {
        name: "BMW M8",
        wheels: 4,
        doors: 4,
        isStarted: false,
        hp: 470
    },
    audi: {
        name: "Audi Q7",
        wheels: 4,
        doors: 4,
        isStarted: false,
        hp: 300
    },
    toyota: {
        name: "Toyota Camry",
        wheels: 4,
        doors: 4,
        isStarted: false,
        hp: 250
    }
};

const getCar = (carName) => {
    const car = cars[carName.toLowerCase()]; 
    if (car) {
        return car; 
    } else {
        console.log("Автомобиль не найден.");
    }
};

console.log(getCar("dodge"));
console.log(getCar("audi"));
console.log(getCar("ford")); 
