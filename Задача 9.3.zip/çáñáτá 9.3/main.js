
function createCar(Properties) {
    const car = {
        wheels: 4,
        doors: 4,
        isStarted: false
    }
    return { ...car, ...Properties };
}

console.log(createCar({name: 'Geely Atlas Pro', hp: 220}));