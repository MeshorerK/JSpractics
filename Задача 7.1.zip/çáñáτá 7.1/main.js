let ulEl
let list = ["Мастер и Маргарита", "Гарри Поттер", "За пропастью во лжи", "Властелин колец", "Дюна", "Отцы и дети"]

const Header = document.createElement('h1');
Header.textContent = 'Домашняя библиотека'
document.body.append(Header)

const Addbutton = document.createElement('button');
Addbutton.classList.add('addbutton');
Addbutton.textContent = 'Добавить книгу'
document.body.append(Addbutton)

const Searchbutton = document.createElement('button');
Searchbutton.textContent = 'Найти'
Searchbutton.classList.add('searchbutton');
document.body.append(Searchbutton)

function newlist() {
  ulEl = document.createElement('ol');
  document.body.append(ulEl)
  updateList()
}

function updateList() {
  ulEl.innerHTML = list.map(v => `<li>${v}</li>`).join('')
}

function Adding() {
  list.push(prompt('Введите название книги'))
  updateList()
}

newlist(list)

Addbutton.onclick = Adding

function filter(arr, search) {
    let result = -1

    for (let i = 0; i < list.length; i++) {
        if (arr[i] === search) {
            result = i
            break
        }
    }
    return result
}

Searchbutton.onclick = function searching() {
    const findbook = prompt('Введите название книги')

    const find = filter(list, findbook)
    
    if (find>-1) {
        document.querySelector(`li:nth-child(${find + 1})`).style.color = 'yellow';
    } else { 
        alert('Книга не найдена!')
    }
}


 
 








