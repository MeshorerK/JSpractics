const celsius = (a) => a * 1.8 + 32
const Fahrenheit = (b) => (b - 32) / 1.8 

console.log(celsius(25), Fahrenheit(77));