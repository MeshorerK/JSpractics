function hello() {
    console.log('Skill');
  }
  
  try { 
    hello(); 
  } catch (error) {
    console.error('Произошла ошибка:', error.message); 
  }
  
  console.log('complete');
  

