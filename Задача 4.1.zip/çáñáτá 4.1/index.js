function summ(a, b, c) {
    if (typeof a == "number" && typeof b == "number" && typeof c == "number") {
        return (a+b+c)/3
    }
    else {
        console.log("Вводные данные не поддерживаются, скорее всего вы использовали слова"); 
    }
}

console.log(summ(4,5,"Строка"));