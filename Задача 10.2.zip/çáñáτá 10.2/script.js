const itemList = document.getElementById('item-list');
const addItemButton = document.getElementById('add-item');
const removeItemButton = document.getElementById('remove-item');

addItemButton.addEventListener('click', () => {
    const newItem = document.createElement('li'); 
    newItem.textContent = 'Новый элемент списка'; 
    itemList.appendChild(newItem); 
});

removeItemButton.addEventListener('click', () => {
    const lastItem = itemList.lastElementChild; 
    if (lastItem) {
        itemList.removeChild(lastItem); 
    } else {
        alert("Список пуст!"); 
    }
});


