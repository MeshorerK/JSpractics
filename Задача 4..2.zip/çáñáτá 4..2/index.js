function celsius(a) {
    if (typeof a == "number") {
        return a * 1.8 + 32
    }
    else {
        console.log("Данные не поддерживаются");
    }
}
function Fahrenheit(b) {
    if (typeof b == "number") {
        return (b - 32) / 1.8 
    }
    else {
        console.log("Данные не поддерживаются");
    }
}

console.log(celsius(25), Fahrenheit(77));